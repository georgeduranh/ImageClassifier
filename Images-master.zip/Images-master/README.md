This repository contains code for augmenting images.

Image Augmentation is done to produce multiple copies of a image by tilting, flipping, zooming or shifting it.
